`timescale 1ns / 1ps

module uart_top_tb;

    // Testbench signals
    reg clk;
    reg reset;
    reg rx;
    
    wire data_ready;
    wire rx_idle;
    wire match;
    wire full;

    // Instantiate DUT
    uart_top dut (
        .clk_125MHz(clk),
        .reset(reset),
        .rx(rx),
        .data_ready(data_ready),
        .rx_idle(rx_idle),
        .match(match),
        .full(full)
    );

    // Clock generation (125 MHz ? 8 ns period)
    always #4 clk = ~clk;

    // UART bit time for 115200 baud
    localparam BIT_TIME = 8680; // ns

    // Task to send one UART byte
    task send_uart_byte;
        input [7:0] data;
        integer i;
        begin
            // Start bit
            rx = 0;
            #(BIT_TIME);

            // Data bits (LSB first)
            for (i = 0; i < 8; i = i + 1) begin
                rx = data[i];
                #(BIT_TIME);
            end

            // Stop bit
            rx = 1;
            #(BIT_TIME);
        end
    endtask

    integer k;

    initial begin
        // Initialize
        clk = 0;
        reset = 1;
        rx = 1;   // idle state is HIGH

        #100;
        reset = 0;

        #10000; // wait some time

        // Send 10 bytes
        send_uart_byte(8'hA5); // will trigger match
        send_uart_byte(8'h12);
        send_uart_byte(8'h34);
        send_uart_byte(8'h56);
        send_uart_byte(8'h78);
        send_uart_byte(8'h9A);
        send_uart_byte(8'hBC);
        send_uart_byte(8'hDE);
        send_uart_byte(8'hF0);
        send_uart_byte(8'h55);

        #100000;
        $stop;
    end

endmodule